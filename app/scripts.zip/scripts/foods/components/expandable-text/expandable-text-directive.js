'use strict';

angular.module('GSH5')
    .directive('expandableText', function() {
        return {
            restrict: 'E',
            templateUrl: 'scripts/foods/components/expandable-text/expandable-text.html',
            scope : {
                gsContent : '@',
                gsCount : '@'
            },
            controller: function($scope) {
                $scope.Infinity = Infinity;
                $scope.currCount = $scope.gsCount;
            }
        };
    });
