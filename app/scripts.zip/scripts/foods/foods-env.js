'use strict';

angular.module('GSH5').factory('FoodsENV', function(){
  return {aa:'123'};
});
